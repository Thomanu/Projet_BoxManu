import React, { Component } from "react";

function Navigation({ children }) {
	return <div className='app__banner'>{children}</div>
}

export default Navigation
